var senha = prompt("Digite sua senha");
var confirmar = prompt("Digite novamente sua senha");

if (senha === confirmar) {
  alert("As senhas são iguais!");
} else {
  alert("As senhas são diferentes");
}
