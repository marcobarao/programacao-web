var numero = prompt("Digite um numero qualquer");

numero = parseInt(numero);

if (numero > 0) {
  alert("POSITIVO");
} else {
  alert("NEGATIVO OU ZERO");
}
